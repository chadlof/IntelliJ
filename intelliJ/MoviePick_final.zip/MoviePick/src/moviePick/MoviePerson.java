package moviePick;

/**
 * Created by valjesc on 12/19/2016.
 */
class MoviePerson {
    private String name;

    public void setName(String Name){
        name = Name;
    }

    public String getName(){
        return name;
    }
}
