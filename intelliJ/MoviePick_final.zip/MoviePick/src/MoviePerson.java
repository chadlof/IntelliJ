/**
 * Created by valjesc on 12/19/2016.
 */
public class MoviePerson {
    private String name;

    public void setName(String Name){
        Name = name;
        return;
    }

    public String getName(){
        return name;
    }

}
